<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/mootools\/([0-9\.]*)\/mootools\-yui\-compressed\.js',
	
);
