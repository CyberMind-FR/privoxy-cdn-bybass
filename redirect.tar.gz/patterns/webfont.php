<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/webfont\/([0-9\.]*)\/webfont\.js',
	
);
