<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/swfobject\/([0-9\.]*)\/swfobject\.js',
	'http\:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/swfobject\/([0-9\.]*)\/swfobject\.js',
	
);
