<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/angularjs\/([0-9\.]*)\/angular\.min\.js',
	
);
