<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\/([0-9\.]*)\/jquery(?:\.min)?\.js',
	'http\:\/\/ajax\.aspnetcdn\.com\/ajax\/jQuery\/jquery\-([0-9\.]*)(\.min)?\.js',
	'http\:\/\/cdn\.jsdelivr\.net\/jquery\/([0-9\.]*)\/jquery(?:\-[0-9\.]*)?(?:\.min)?\.js',
	'http\:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jquery\/([0-9\.]*\-?(rc|beta)?[0-9]?)\/jquery(?:\.min)?\.js',
	
);
