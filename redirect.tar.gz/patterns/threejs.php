<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/threejs\/(r[0-9]*)\/three(?:\.min)?\.js',
	'http\:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/three\.js\/(r[0-9]*)\/three(?:\.min)?\.js',
	'http\:\/\/cdn\.jsdelivr\.net\/threejs\/(r[0-9]*)\/three(?:\.min)?\.js',
);
