<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/scriptaculous\/([0-9\.]*)\/scriptaculous\.js',
	
);
