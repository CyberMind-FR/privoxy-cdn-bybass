<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/dojo\/([0-9\.]*)\/dojo\/dojo\.js',
	
);
