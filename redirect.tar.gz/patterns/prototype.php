<?php

return array(

	'http\:\/\/ajax\.googleapis\.com\/ajax\/libs\/prototype\/([0-9\.]*)\/prototype\.js',
	
);
